const { Pool } = require('pg');

/*
 * Hearttwin DB wrapper – v2
 * - SSL erzwungen (require:true, rejectUnauthorized:false)
 * - Normalisierung: akzeptiert camelCase und snake_case Felder
 * - Setzt Default-Werte für Arrays/Objekte, damit z.B. matches.includes nie crasht
 */

const pool = new Pool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT ? Number(process.env.DB_PORT) : 5432,
  database: process.env.DB_NAME,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  ssl: { require: true, rejectUnauthorized: false },
});

// Convert a value into an array.  Historically some JSONB fields were
// stored as strings or PostgreSQL array literals (e.g. "{0049,0043}" or
// "{\"0049\"}").  This helper attempts to normalise these
// legacy formats into proper JavaScript arrays.  If the value is
// already an array it is returned unchanged.  If the value is a Set
// it is converted to an array.  If the value looks like a
// PostgreSQL array literal wrapped in curly braces, it will be
// split on commas after stripping the braces and any quotes.  If the
// value is a JSON string that parses to an array, that array will
// be returned.  Otherwise an empty array is returned.
function toArray(value) {
  if (Array.isArray(value)) return value;
  if (value instanceof Set) return Array.from(value);
  if (typeof value === 'string') {
    const trimmed = value.trim();
    // PostgreSQL array literal
    if (/^\{.*\}$/.test(trimmed)) {
      let inner = trimmed.slice(1, -1);
      // Remove surrounding quotes from each element ("foo" -> foo)
      const parts = inner
        .split(/,/)
        .map(p => p.trim())
        .filter(p => p.length > 0)
        .map(p => p.replace(/^"(.*)"$/, '$1'));
      return parts;
    }
    // Try parse JSON array string
    try {
      const parsed = JSON.parse(trimmed);
      if (Array.isArray(parsed)) return parsed;
    } catch (err) {
      // ignore
    }
  }
  return [];
}

// Convert a value into a plain object (not array).  If the value is a
// string containing JSON, attempt to parse it; otherwise return an
// empty object for falsy or non-object values.
function toObject(value) {
  if (!value) return {};
  if (typeof value === 'string') {
    try {
      const parsed = JSON.parse(value);
      if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) return parsed;
    } catch (_) {}
  }
  if (typeof value === 'object' && !Array.isArray(value)) return value;
  return {};
}

// Parse a JSON string into an object or return the original object.  If
// parsing fails, return null.  This is used to normalise profile
// values which might be stored as a JSON string.
function parseJsonMaybe(value) {
  if (value == null) return null;
  if (typeof value === 'string') {
    try {
      const parsed = JSON.parse(value);
      return parsed;
    } catch (_) {
      return null;
    }
  }
  return typeof value === 'object' ? value : null;
}

// Mappt camelCase -> snake_case und setzt sinnvolle Defaults
function normalizeUser(u = {}) {
  const n = (v, d) => (v === undefined ? d : v);
  const out = {
    country_code: n(u.country_code ?? u.countryCode, null),
    phone: n(u.phone, null),
    password: n(u.password, null),
    birth_date: n(u.birth_date ?? u.birthDate, null),
    activated: n(u.activated, false),
    verification_code: n(u.verification_code ?? u.verificationCode, null),
    reset_code: n(u.reset_code ?? u.resetCode, null),
    locked: n(u.locked, false),
    locked_by_admin: n(u.locked_by_admin ?? u.lockedByAdmin, false),
    failed_attempts: n(u.failed_attempts ?? u.failedAttempts, 0),
    is_admin: n(u.is_admin ?? u.isAdmin, false),
    // Convert JSON strings for profile into objects
    profile: parseJsonMaybe(u.profile),
    // Normalise list-like fields using toArray() to avoid invalid JSON
    // inputs when storing back to PostgreSQL.  This converts legacy
    // string formats (e.g. "{0049}" or "{\"0049\"}") into
    // proper arrays.  If the value is undefined we default to [] or
    // an empty object where appropriate.
    matches: toArray(u.matches ?? u.matches_json),
    ki_matches: toArray(u.ki_matches ?? u.kiMatches),
    blocked: toArray(u.blocked),
    unseen_matches: toArray(u.unseen_matches),
    unseen_ki_matches: toArray(u.unseen_ki_matches),
    chats: toObject(u.chats),
    unread_chat_count: toObject(u.unread_chat_count ?? u.unreadChatCount),
    unread_matches: n(u.unread_matches, 0),
    nickname: n(u.nickname, null),
    nickname_immutable: n(u.nickname_immutable ?? u.nicknameImmutable, false),
    about_changed_at: n(u.about_changed_at ?? u.aboutChangedAt, null),
    verified: n(u.verified, false),
    verification_pending: n(u.verification_pending, false),
    paused: n(u.paused, false),
    created_at: n(u.created_at ?? u.createdAt, null),
  };
  return out;
}

async function init() {
  // Retained for backwards compatibility – creates only the users table.
  // Use initDatabase() to create all required tables when using the
  // extended chat/match functionality.  See initDatabase() below.
  const createTableSQL = `
    CREATE TABLE IF NOT EXISTS users (
      id SERIAL PRIMARY KEY,
      country_code TEXT NOT NULL,
      phone TEXT NOT NULL UNIQUE,
      password TEXT NOT NULL,
      birth_date TEXT NOT NULL,
      activated BOOLEAN DEFAULT FALSE,
      verification_code TEXT,
      reset_code TEXT,
      locked BOOLEAN DEFAULT FALSE,
      locked_by_admin BOOLEAN DEFAULT FALSE,
      failed_attempts INTEGER DEFAULT 0,
      is_admin BOOLEAN DEFAULT FALSE,
      profile JSONB,
      matches JSONB,
      ki_matches JSONB,
      chats JSONB,
      unread_chat_count JSONB,
      unread_matches INTEGER DEFAULT 0,
      nickname TEXT,
      nickname_immutable BOOLEAN DEFAULT FALSE,
      about_changed_at TEXT,
      blocked JSONB,
      unseen_matches JSONB,
      unseen_ki_matches JSONB,
      verified BOOLEAN DEFAULT FALSE,
      verification_pending BOOLEAN DEFAULT FALSE,
      paused BOOLEAN DEFAULT FALSE,
      created_at TIMESTAMPTZ DEFAULT NOW()
    );
  `;
  await pool.query(createTableSQL);
}

/**
 * Initialise the entire database schema for Hearttwin.  This function
 * creates the users table (like init()), as well as tables for
 * conversations, messages, matches and blocks.  It also sets up
 * necessary indexes and the match_source ENUM type.  Call this
 * function when starting the server to ensure all required tables
 * exist.
 */
async function initDatabase() {
  // Create users table.  Use the same definition as in init().
  await init();
  // Conversations table for 1‑zu‑1‑Chats.
  // Hinweis: PostgreSQL erlaubt keine Ausdrucks‑UNIQUE‑Constraints in der
  // CREATE TABLE‑Klausel.  Deshalb wird die Tabelle zunächst ohne
  // solche Constraints erstellt und der UNIQUE‑Index anschließend
  // separat angelegt.
  await pool.query(`
    CREATE TABLE IF NOT EXISTS conversations (
      id BIGSERIAL PRIMARY KEY,
      user_a BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      user_b BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      created_at TIMESTAMPTZ DEFAULT NOW(),
      last_msg_at TIMESTAMPTZ
    );
  `);
  // Erstelle die einzigartigen und zusätzlichen Indizes separat.
  await pool.query(`CREATE UNIQUE INDEX IF NOT EXISTS conversations_pair_uniq ON conversations (LEAST(user_a, user_b), GREATEST(user_a, user_b));`);
  await pool.query(`CREATE INDEX IF NOT EXISTS conversations_user_a_idx ON conversations(user_a);`);
  await pool.query(`CREATE INDEX IF NOT EXISTS conversations_user_b_idx ON conversations(user_b);`);
  // Messages table.  A row per message with optional read_at timestamp.
  await pool.query(`
    CREATE TABLE IF NOT EXISTS messages (
      id BIGSERIAL PRIMARY KEY,
      conversation_id BIGINT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
      sender_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      body TEXT NOT NULL,
      created_at TIMESTAMPTZ DEFAULT NOW(),
      read_at TIMESTAMPTZ
    );
    CREATE INDEX IF NOT EXISTS messages_conv_created_idx ON messages(conversation_id, created_at DESC);
    CREATE INDEX IF NOT EXISTS messages_sender_idx ON messages(sender_id, created_at DESC);
  `);
  // Define the enum type for match sources if it does not already exist.
  await pool.query(`
    DO $$
    BEGIN
      IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'match_source') THEN
        CREATE TYPE match_source AS ENUM ('profile', 'ai');
      END IF;
    END $$;
  `);
  // Matches table to store recommendations between users.  The
  // combination of user_id, partner_id and source must be unique.
  await pool.query(`
    CREATE TABLE IF NOT EXISTS matches (
      id BIGSERIAL PRIMARY KEY,
      user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      partner_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      source match_source NOT NULL DEFAULT 'profile',
      created_at TIMESTAMPTZ DEFAULT NOW(),
      seen BOOLEAN DEFAULT FALSE,
      UNIQUE (user_id, partner_id, source)
    );
    CREATE INDEX IF NOT EXISTS matches_partner_idx ON matches(partner_id);
  `);
  // Blocks table.  Prevents a user from interacting with another.
  await pool.query(`
    CREATE TABLE IF NOT EXISTS blocks (
      id BIGSERIAL PRIMARY KEY,
      user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      blocked_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      created_at TIMESTAMPTZ DEFAULT NOW(),
      UNIQUE (user_id, blocked_id),
      CHECK (user_id <> blocked_id)
    );
  `);
}

/**
 * Create or fetch a conversation between two users.  If a conversation
 * already exists for the unordered pair (userA,userB), the existing
 * conversation id is returned and its last_msg_at timestamp is not
 * updated.  If no conversation exists, a new one is created.
 *
 * @param {number} userA - The id of the first user
 * @param {number} userB - The id of the second user
 * @returns {Promise<number>} The conversation id
 */
async function createConversation(userA, userB) {
  const { rows } = await pool.query(
    `INSERT INTO conversations (user_a, user_b)
     VALUES ($1, $2)
     ON CONFLICT (LEAST(user_a, user_b), GREATEST(user_a, user_b))
     DO UPDATE SET last_msg_at = conversations.last_msg_at
     RETURNING id;`,
    [userA, userB]
  );
  return rows[0].id;
}

/**
 * Persist a new message in a conversation and update the
 * conversation's last message timestamp.
 *
 * @param {number} conversationId - The conversation id
 * @param {number} senderId - The id of the sender
 * @param {string} body - The message body
 */
async function saveMessage(conversationId, senderId, body) {
  await pool.query(
    `INSERT INTO messages (conversation_id, sender_id, body)
     VALUES ($1, $2, $3)`,
    [conversationId, senderId, body]
  );
  await pool.query(
    `UPDATE conversations
     SET last_msg_at = NOW()
     WHERE id = $1`,
    [conversationId]
  );
}

/**
 * Retrieve messages for a conversation ordered by creation time
 * ascending.  Supports pagination via limit and offset.
 *
 * @param {number} conversationId - The conversation id
 * @param {number} [limit=20] - Number of messages to return
 * @param {number} [offset=0] - Offset for pagination
 * @returns {Promise<Array>} Array of message rows including sender nickname
 */
async function getMessages(conversationId, limit = 20, offset = 0) {
  const { rows } = await pool.query(
    `SELECT m.id, m.sender_id, m.body, m.created_at, u.nickname
     FROM messages m
       JOIN users u ON u.id = m.sender_id
     WHERE m.conversation_id = $1
     ORDER BY m.created_at ASC
     LIMIT $2 OFFSET $3`,
    [conversationId, limit, offset]
  );
  return rows;
}

/**
 * Create a match record for a user with a partner.  If the same
 * combination of userId, partnerId and source already exists, this
 * function does nothing.
 *
 * @param {number} userId - The id of the user receiving the match
 * @param {number} partnerId - The id of the partner suggested
 * @param {string} [source='profile'] - The source of the match
 */
async function createMatch(userId, partnerId, source = 'profile') {
  await pool.query(
    `INSERT INTO matches (user_id, partner_id, source)
     VALUES ($1, $2, $3)
     ON CONFLICT (user_id, partner_id, source) DO NOTHING`,
    [userId, partnerId, source]
  );
}

/**
 * Fetch all matches for a given user ordered by creation time
 * descending.  Returns partner_id, source, created_at and seen
 * boolean.
 *
 * @param {number} userId - The id of the user
 * @returns {Promise<Array>} Array of match records
 */
async function getMatches(userId) {
  const { rows } = await pool.query(
    `SELECT partner_id, source, created_at, seen
     FROM matches
     WHERE user_id = $1
     ORDER BY created_at DESC`,
    [userId]
  );
  return rows;
}

/**
 * Mark a match as seen for a user.
 *
 * @param {number} userId - The id of the user
 * @param {number} partnerId - The id of the matched partner
 */
async function markMatchSeen(userId, partnerId) {
  await pool.query(
    `UPDATE matches
     SET seen = TRUE
     WHERE user_id = $1 AND partner_id = $2`,
    [userId, partnerId]
  );
}

/**
 * Block a user by inserting a row into the blocks table.  If the pair
 * already exists the insertion is ignored.  Note that attempts to
 * block oneself are silently ignored by the database CHECK constraint.
 *
 * @param {number} userId - The id of the user performing the block
 * @param {number} blockedId - The id of the user to be blocked
 */
async function blockUser(userId, blockedId) {
  await pool.query(
    `INSERT INTO blocks (user_id, blocked_id)
     VALUES ($1, $2)
     ON CONFLICT (user_id, blocked_id) DO NOTHING`,
    [userId, blockedId]
  );
}

/**
 * Retrieve an array of user ids that a given user has blocked.
 *
 * @param {number} userId - The id of the user
 * @returns {Promise<Array<number>>} Array of blocked user ids
 */
async function getBlockedUsers(userId) {
  const { rows } = await pool.query(
    `SELECT blocked_id
     FROM blocks
     WHERE user_id = $1`,
    [userId]
  );
  return rows.map(r => r.blocked_id);
}

async function getAllUsers() {
  const { rows } = await pool.query('SELECT * FROM users');
  return rows.map(rowToUser);
}

async function getUserByPhone(countryCode, phone) {
  const { rows } = await pool.query(
    'SELECT * FROM users WHERE country_code = $1 AND phone = $2',
    [countryCode, phone]
  );
  return rows.length > 0 ? rowToUser(rows[0]) : null;
}

async function getUserByNickname(nickname) {
  const { rows } = await pool.query(
    'SELECT * FROM users WHERE LOWER(nickname) = LOWER($1)',
    [nickname]
  );
  return rows.length > 0 ? rowToUser(rows[0]) : null;
}

async function createUser(user) {
  const u = normalizeUser(user);
  const fields = [
    'country_code','phone','password','birth_date','activated',
    'verification_code','reset_code','locked','locked_by_admin',
    'failed_attempts','is_admin','profile','matches','ki_matches',
    'chats','unread_chat_count','unread_matches','nickname',
    'nickname_immutable','about_changed_at','blocked',
    'unseen_matches','unseen_ki_matches','verified',
    'verification_pending','paused','created_at'
  ];
  const values = fields.map(f => u[f] === undefined ? null : u[f]);
  const placeholders = fields.map((_, i) => `$${i + 1}`).join(', ');
  const sql = `INSERT INTO users (${fields.join(', ')}) VALUES (${placeholders}) RETURNING *`;
  const { rows } = await pool.query(sql, values);
  return rowToUser(rows[0]);
}

async function updateUser(user) {
  const u = normalizeUser(user);
  const columns = [];
  const values = [];
  let idx = 1;
  for (const [key, value] of Object.entries(u)) {
    if (value === undefined) continue;
    if (key === 'country_code' || key === 'phone') continue;
    columns.push(`${key} = $${idx}`);
    values.push(value);
    idx++;
  }
  if (columns.length === 0) return null;
  values.push(u.country_code);
  values.push(u.phone);
  const sql = `UPDATE users SET ${columns.join(', ')} WHERE country_code = $${idx} AND phone = $${idx + 1} RETURNING *`;
  const { rows } = await pool.query(sql, values);
  return rows.length > 0 ? rowToUser(rows[0]) : null;
}

function rowToUser(row) {
  if (!row) return null;
  return {
    id: row.id,
    countryCode: row.country_code,
    phone: row.phone,
    password: row.password,
    birthDate: row.birth_date,
    activated: row.activated,
    verificationCode: row.verification_code,
    resetCode: row.reset_code,
    locked: row.locked,
    lockedByAdmin: row.locked_by_admin,
    failedAttempts: row.failed_attempts,
    isAdmin: row.is_admin,
    profile: row.profile,
    matches: row.matches || [],
    kiMatches: row.ki_matches || [],
    chats: row.chats || {},
    unreadChatCount: row.unread_chat_count || {},
    unreadMatches: row.unread_matches,
    nickname: row.nickname,
    nicknameImmutable: row.nickname_immutable,
    aboutChangedAt: row.about_changed_at,
    blocked: row.blocked || [],
    unseenMatches: row.unseen_matches || [],
    unseenKiMatches: row.unseen_ki_matches || [],
    verified: row.verified,
    verificationPending: row.verification_pending,
    paused: row.paused,
    createdAt: row.created_at
  };
}

module.exports = {
  pool,
  init,
  // Export initDatabase to initialise all tables
  initDatabase,
  getAllUsers,
  getUserByPhone,
  getUserByNickname,
  createUser,
  updateUser,
  // Conversation API
  createConversation,
  saveMessage,
  getMessages,
  // Match API
  createMatch,
  getMatches,
  markMatchSeen,
  // Blocking API
  blockUser,
  getBlockedUsers,
};
