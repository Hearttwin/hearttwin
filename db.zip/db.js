const { Pool } = require('pg');

/*
 * Simple database wrapper for Hearttwin.
 *
 * This module initialises a PostgreSQL connection pool using environment
 * variables defined in the `.env` file (DB_HOST, DB_PORT, DB_NAME,
 * DB_USER, DB_PASSWORD).  It provides helper functions to create the
 * users table on startup and to perform basic CRUD operations on the
 * user records.  JSON fields are stored using PostgreSQL's native
 * `jsonb` type.  See server.js for usage.
 */

// Create a connection pool from environment variables.  If any of
// these values are undefined the pg library will throw an error on
// first use, so ensure DB_HOST, DB_NAME, DB_USER and DB_PASSWORD are
// defined in .env.
const pool = new Pool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT ? Number(process.env.DB_PORT) : 5432,
  database: process.env.DB_NAME,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD
});

/**
 * Initialise the database by creating the users table if it does not
 * already exist.  The table stores most user properties as columns.
 * Complex objects such as matches, chats and profiles are stored as
 * JSONB for simplicity.  Additional columns can be added easily
 * without modifying the rest of the application.
 */
async function init() {
  const createTableSQL = `
    CREATE TABLE IF NOT EXISTS users (
      id SERIAL PRIMARY KEY,
      country_code TEXT NOT NULL,
      phone TEXT NOT NULL UNIQUE,
      password TEXT NOT NULL,
      birth_date TEXT NOT NULL,
      activated BOOLEAN DEFAULT FALSE,
      verification_code TEXT,
      reset_code TEXT,
      locked BOOLEAN DEFAULT FALSE,
      locked_by_admin BOOLEAN DEFAULT FALSE,
      failed_attempts INTEGER DEFAULT 0,
      is_admin BOOLEAN DEFAULT FALSE,
      profile JSONB,
      matches JSONB,
      ki_matches JSONB,
      chats JSONB,
      unread_chat_count JSONB,
      unread_matches INTEGER DEFAULT 0,
      nickname TEXT,
      nickname_immutable BOOLEAN DEFAULT FALSE,
      about_changed_at TEXT,
      blocked JSONB,
      unseen_matches JSONB,
      unseen_ki_matches JSONB,
      verified BOOLEAN DEFAULT FALSE,
      verification_pending BOOLEAN DEFAULT FALSE,
      paused BOOLEAN DEFAULT FALSE
    );
  `;
  await pool.query(createTableSQL);
}

/**
 * Retrieve all users from the database.  Returns an array of user
 * objects.  JSON fields are parsed automatically by the pg driver.
 */
async function getAllUsers() {
  const { rows } = await pool.query('SELECT * FROM users');
  return rows.map(rowToUser);
}

/**
 * Find a user by country code and phone number.  Returns a user
 * object or null.
 */
async function getUserByPhone(countryCode, phone) {
  const { rows } = await pool.query(
    'SELECT * FROM users WHERE country_code = $1 AND phone = $2',
    [countryCode, phone]
  );
  return rows.length > 0 ? rowToUser(rows[0]) : null;
}

/**
 * Find a user by nickname (case insensitive).  Returns a user or null.
 */
async function getUserByNickname(nickname) {
  const { rows } = await pool.query(
    'SELECT * FROM users WHERE LOWER(nickname) = LOWER($1)',
    [nickname]
  );
  return rows.length > 0 ? rowToUser(rows[0]) : null;
}

/**
 * Insert a new user into the database.  Accepts a user object with
 * properties matching the users table.  Returns the inserted user
 * record.
 */
async function createUser(user) {
  const fields = [
    'country_code', 'phone', 'password', 'birth_date', 'activated',
    'verification_code', 'reset_code', 'locked', 'locked_by_admin',
    'failed_attempts', 'is_admin', 'profile', 'matches', 'ki_matches',
    'chats', 'unread_chat_count', 'unread_matches', 'nickname',
    'nickname_immutable', 'about_changed_at', 'blocked',
    'unseen_matches', 'unseen_ki_matches', 'verified',
    'verification_pending', 'paused'
  ];
  const values = fields.map(f => user[f] === undefined ? null : user[f]);
  const placeholders = fields.map((_, i) => `$${i + 1}`).join(', ');
  const sql = `INSERT INTO users (${fields.join(', ')}) VALUES (${placeholders}) RETURNING *`;
  const { rows } = await pool.query(sql, values);
  return rowToUser(rows[0]);
}

/**
 * Update an existing user record.  The user object must include
 * country_code and phone to identify the record.  Only the fields
 * provided will be updated.  Returns the updated user or null if no
 * record was found.
 */
async function updateUser(user) {
  // Build dynamic SET clause.  Skip undefined values and identifying fields.
  const columns = [];
  const values = [];
  let idx = 1;
  for (const [key, value] of Object.entries(user)) {
    if (value === undefined) continue;
    if (key === 'country_code' || key === 'phone') continue;
    columns.push(`${key} = $${idx}`);
    values.push(value);
    idx++;
  }
  if (columns.length === 0) return null;
  // Add identifying fields
  values.push(user.country_code);
  values.push(user.phone);
  const sql = `UPDATE users SET ${columns.join(', ')} WHERE country_code = $${idx} AND phone = $${idx + 1} RETURNING *`;
  const { rows } = await pool.query(sql, values);
  return rows.length > 0 ? rowToUser(rows[0]) : null;
}

/**
 * Convert a database row to a user object.  The pg driver returns
 * JSONB fields as plain JavaScript objects.  This helper normalises
 * property names to match the user model used throughout the server.
 */
function rowToUser(row) {
  if (!row) return null;
  return {
    id: row.id,
    countryCode: row.country_code,
    phone: row.phone,
    password: row.password,
    birthDate: row.birth_date,
    activated: row.activated,
    verificationCode: row.verification_code,
    resetCode: row.reset_code,
    locked: row.locked,
    lockedByAdmin: row.locked_by_admin,
    failedAttempts: row.failed_attempts,
    isAdmin: row.is_admin,
    profile: row.profile,
    matches: row.matches || [],
    kiMatches: row.ki_matches || [],
    chats: row.chats || {},
    unreadChatCount: row.unread_chat_count || {},
    unreadMatches: row.unread_matches,
    nickname: row.nickname,
    nicknameImmutable: row.nickname_immutable,
    aboutChangedAt: row.about_changed_at,
    blocked: row.blocked || [],
    unseenMatches: row.unseen_matches || [],
    unseenKiMatches: row.unseen_ki_matches || [],
    verified: row.verified,
    verificationPending: row.verification_pending,
    paused: row.paused
  };
}

module.exports = {
  pool,
  init,
  getAllUsers,
  getUserByPhone,
  getUserByNickname,
  createUser,
  updateUser
};