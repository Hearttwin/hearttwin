/*
 * Registriert den Service Worker für Hearttwin, sobald die Seite
 * geladen wurde.  Prüft, ob der Browser Service Worker unterstützt
 * und gibt ggf. Fehlermeldungen in der Konsole aus.
 */
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/service-worker.js').catch(err => {
      console.warn('Service Worker konnte nicht registriert werden:', err);
    });
  });
}