/*
 * Hearttwin Service Worker
 *
 * Dieser einfache Service Worker legt die Kernressourcen der Anwendung
 * im Cache ab und bedient sie aus dem Cache, wenn sie offline oder
 * langsam geladen werden.  Für dynamische Anfragen (z. B. API‑Calls)
 * wird weiterhin das Netzwerk verwendet.  Bei Bedarf können Sie
 * zusätzliche URLs zu der Liste `urlsToCache` hinzufügen.
 */

const CACHE_NAME = 'hearttwin-cache-v1';
const urlsToCache = [
  '/',
  '/index.html',
  '/styles.css',
  '/logo.png',
  '/register.html',
  '/login.html',
  '/agb.html',
  '/impressum.html',
  '/match.html',
  '/matches.html',
  '/match.html',
  '/forgot.html',
  '/profile.html',
  '/view-profile.html',
  '/admin.html',
  '/chats.html',
  '/ki-chats.html',
  '/ki-matches.html'
];

self.addEventListener('install', event => {
  // Installationsschritt: Ressourcen cachen
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      return cache.addAll(urlsToCache);
    })
  );
});

self.addEventListener('activate', event => {
  // Aufräumen alter Caches
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheName !== CACHE_NAME) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});

self.addEventListener('fetch', event => {
  // Versuche, statische Ressourcen aus dem Cache zu bedienen
  // API‑Anfragen werden direkt an das Netz weitergereicht
  const req = event.request;
  // Wir bedienen nur GET‑Anfragen aus dem Cache
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  // Ignoriere andere Hosts
  if (url.origin !== self.location.origin) return;
  event.respondWith(
    caches.match(req).then(cached => {
      return cached || fetch(req);
    })
  );
});